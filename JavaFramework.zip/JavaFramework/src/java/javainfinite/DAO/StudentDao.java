/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javainfinite.DAO;

import java.util.List;
import javainfinite.pojo.StudentDetails;

/**
 *
 * @author LENOVO
 */
public interface StudentDao {
    public void saveStudent (StudentDetails student);
    public List<StudentDetails> showAllStudents();
    public void updateStudent (int id, String name, String coursename, String address, String contactno, String emailid, String rollno, String marks, String remarks);
    public void deleteStudent (StudentDetails student);
}
